import os
import json
import urllib
import urllib.request
import hashlib
import shutil
import sys
import sonofindNC as sfnc

class sonofindAPIError(Exception):
	def __init__(self, message, code):
		self.message = message
		self.code = code
	pass

class sonofindAPI():

	def __init__(self, url, verbmode=0):
		self.server=url
		self.url=self.server + '/search/html/ajax/axExtData.php'
		self.sid=''
		self.opener = urllib.request.build_opener()
		self.verbmode=verbmode
		self.NC = sfnc.sonofindNC()
		
	def login(self, cuser, cpass):
		response = self.opener.open(self.url+'?ac=opensession')
		html = response.read()
		myjson = json.loads(html)
		self.sid=myjson['sid']
		m=hashlib.md5()
		m.update(('%s~%s' % (cpass, self.sid)).encode('utf-8'))
		lpass=m.hexdigest()
		url0=self.url+'?ac=login&luser='+cuser+'&lpass='+lpass
		self.opener.addheaders.append(('Cookie', 'PHPSESSID='+self.sid+';'))
		response = self.opener.open(url0)
		html = response.read()
		myjson = json.loads(html)

		if (myjson['ax_success'] != 1):
		  raise sonofindAPIError("Unable to login:"+myjson['ax_errmsg'],500)

	def createDestPath(self, destfile):
		outdir=os.path.dirname(destfile)
		if(not os.path.isdir(outdir)):
			## create directory
			os.makedirs(outdir)

	def copyFile(self, ffilename, destfile):
		self.createDestPath(destfile)
		shutil.copy2(ffilename,destfile)

	def downloadWFMFile(self, ffilename, destfile):
		try:
			self.NC.checkFilename(trackcode)
		except sfnc.sfNCError as e:
			msg = "{0}:{1}".format(trackcode.strip(),str(e))
			raise sonofindAPIError(msg,501)
		else:
			self.createDestPath(destfile)
			ffilename = ffilename.replace("/","\\")
			x = ffilename.split("\\")
			if(len(x)) >= 3:
				cdkurz = x[2].replace('.wfm','')
				wfmurl=self.server + '/search/html/wfm2png.php?cdkurz={0}'.format(cdkurz)
				print(wfmurl + ":" + destfile)
				dlmp3 = self.opener.open(wfmurl)
				with open(destfile, 'wb') as filee:
					filee.write(dlmp3.read())
				#print str(dlmp3.getcode())+":"+destfile

	def downloadCover(self, ffilename, destfile, coversize=150):
		ffilename = ffilename.replace("/","\\")
		x = ffilename.split("\\")
		if(len(x)) >= 2:
			try:
				self.NC.checkFilenameAlbum(x[1])
			except sfnc.sfNCError as e:
				msg = "{0}:{1}".format(x[1].strip(),str(e))
				raise sonofindAPIError(msg,501)
			else:
				self.createDestPath(destfile)
				cdkurz = x[1].replace('.jpg','')
				wfmurl=self.server + '/search/html/cover.php?cdkurz={0}&size={1}'.format(cdkurz,coversize)
				print(wfmurl + ":" + destfile)
				dlmp3 = self.opener.open(wfmurl)
				with open(destfile, 'wb') as filee:
					filee.write(dlmp3.read())
				#print str(dlmp3.getcode())+":"+destfile
			
	def downloadMP3File(self, trackcode, destfile):
		try:
			self.NC.checkFilename(trackcode)
		except sfnc.sfNCError as e:
			msg = "{0}:{1}".format(trackcode.strip(),str(e))
			raise sonofindAPIError(msg,501)
		else:
			outdir=os.path.dirname(destfile)
			if(not os.path.isdir(outdir)):
				## create directory
				os.makedirs(outdir)
			url0=self.url+'?ac=download&cdkurz='+trackcode+'&type=0&dFlag=2&rsrc=0&ext=1&sprache=EN'
			response = self.opener.open(url0)
			html = response.read()
			myjson = json.loads(html)
			if (myjson['ax_success'] != 1):
				raise sonofindAPIError("Unable to fetch file",400)
				
			mp3url = myjson['url'].replace("/html/../","/")
			dlmp3 = self.opener.open(mp3url)
			with open(destfile, 'wb') as filee:
				filee.write(dlmp3.read())

	def downloadAIFFile(self, trackcode, destfile):
		try:
			self.NC.checkFilename(trackcode)
		except sfnc.sfNCError as e:
			msg = "{0}:{1}".format(trackcode.strip(),str(e))
			raise sonofindAPIError(msg,501)
		else:
			outdir=os.path.dirname(destfile)
			if(not os.path.isdir(outdir)):
				## create directory
				os.makedirs(outdir)
			url0=self.url+'?ac=download&cdkurz='+trackcode+'&type=3&dFlag=2&rsrc=0&ext=1&sprache=EN'
			response = self.opener.open(url0)
			html = response.read()
			myjson = json.loads(html)
			if (myjson['ax_success'] != 1):
				raise sonofindAPIError("Unable to fetch file",400)
				
			mp3url = myjson['url'].replace("/html/../","/")
			dlmp3 = self.opener.open(mp3url)
			with open(destfile, 'wb') as filee:
				filee.write(dlmp3.read())

	def downloadWAVfile(self, trackcode, destfile):
		try:
			self.NC.checkFilename(trackcode)
		except sfnc.sfNCError as e:
			msg = "{0}:{1}".format(trackcode.strip(),str(e))
			raise sonofindAPIError(msg,501)
		else:
			outdir=os.path.dirname(destfile)
			if(not os.path.isdir(outdir)):
				## create directory
				os.makedirs(outdir)
			url0=self.url+'?ac=download&cdkurz='+trackcode+'&type=1&dFlag=2&rsrc=0&ext=1&sprache=EN'
			response = self.opener.open(url0)
			html = response.read()
			myjson = json.loads(html)
			if (myjson['ax_success'] != 1):
				raise sonofindAPIError("Unable to fetch file",400)
				
			mp3url = myjson['url'].replace("/html/../","/")
			dlmp3 = self.opener.open(mp3url)
			with open(destfile, 'wb') as filee:
				filee.write(dlmp3.read())

	def msg(self, msg, verbmode):
		if(self.verbmode >= verbmode):
			print(msg)
