#!/usr/bin/python
## Check if PARIGO files are there
import os
import json
import urllib
import urllib.request
import hashlib
import shutil

import sonofindAPI as SF

with open('config.json') as json_data_file:
	data = json.load(json_data_file)

sonofind = SF.sonofindAPI(data["sonofind"]["host"])
sonofind.login(data["sonofind"]["user"],data["sonofind"]["passwd"])
localcoverstore=data["localstorage"]["coverstorage"]
localwfmdownload=data["localstorage"]["coverdownload"]
coversize = data["localstorage"]["coversize"]

with open('log/missing_covers.txt', 'w') as logfile:

	with open("newfiles_covers.txt") as file:
		for line in file:
			filename=(line.strip().split(":"))[0].lower()
			logfile.flush()
			if (filename[0]=="#"):
				continue
			ffilename = os.path.join(*filename.split("\\"))
			infile=os.path.join(localcoverstore,*filename.split("\\"))
			if (not os.path.isfile(infile)):
				try:
					logfile.write("load:{0}\n".format(ffilename))
					sonofind.downloadCover(ffilename,infile,coversize)
				except urllib.request.HTTPError as e:
					logfile.write("err:{0}:HTTPError Code:{1}\n".format(ffilename,str(e.code)))
					print (ffilename + ":" + str(e.code))
				except Exception as e:
					logfile.write("err:{0}:{1}\n".format(ffilename,str(e)))
					print (ffilename + ":" + str(e))
