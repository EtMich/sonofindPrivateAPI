SONOfind download tool - Michael Ettl - 2019

Please provide settings in config.json

localstorage section defines the storage places for different download types.

the ...storage is always the folder which is looked up for existing files (these files will be skipped)
the ...download folder is the folder where the download will be stored

therefor it would be possible to use your hd musicstation as the storage folder and download missing files to a different folder


If the transfer was interrupted, no Problem, it will check which files already exist on the local drive and skip them.

Log files (e.g. missing file messages) can be found in the log\ directory.

