#!/usr/bin/python
## Check if PARIGO files are there
import os
import json
import urllib
import urllib.request
import hashlib
import sys, getopt

import sonofindAPI as SF

verbmode=0
sLogfile='log/missing_mp3.txt'
sOpts="Fetch MP3 files from a SONOfind server using a copylist\n\n"
sOpts=sOpts+sys.argv[0]+" <options>\n\nOptions:\n-h\thelp\n-v\tbe verbose\n-l filename (--logfile)\tname of logfile"
try:
  opts, args = getopt.getopt(sys.argv[1:],"vhl:",["logfile="])
except getopt.GetoptError:
  print(sOpts)
  sys.exit(2)
for opt, arg in opts:
  if opt == '-h':
    print(sOpts)
    sys.exit()
  elif opt in ("-v"):
    verbmode = 1
  elif opt in ("-l", "--logfile"):
    sLogfile = arg

with open('config.json') as json_data_file:
    data = json.load(json_data_file)

sonofind = SF.sonofindAPI(data["sonofind"]["host"],verbmode)
sonofind.login(data["sonofind"]["user"],data["sonofind"]["passwd"])
localwfmstore=data["localstorage"]["mp3storage"]
localwfmdownload=data["localstorage"]["mp3download"]
sonofind.msg("Starting with these settings\n--------------------------------------------",1)
sonofind.msg("Server:\t"+data["sonofind"]["host"],1)
sonofind.msg("User:\t"+data["sonofind"]["user"],1)
sonofind.msg("Local MP3 Path to locate files in:\t"+data["localstorage"]["mp3storage"],1)
sonofind.msg("Local MP3 Path for new downloads:\t"+data["localstorage"]["mp3download"],1)
sonofind.msg("--------------------------------------------",1)

with open(sLogfile, 'w') as logfile:
  #opener = urllib.request.build_opener()

  with open("newfiles_mp3.txt") as file:
    for line in file:
      filename=(line.strip().split(":"))[0]
      if (filename[0]=="#"):
        continue
      infile=os.path.join(localwfmstore,*filename.split("\\"))
      if (not os.path.isfile(infile)):
        trackcode=os.path.basename(infile).split(".")[0]
        sonofind.msg(trackcode+":"+infile,0)
        try:
          sonofind.downloadMP3File(trackcode,infile)
        except SF.sonofindAPIError as e:
          logfile.write("err:{0}:{1}\n".format(infile,str(e)))
          print("Unable to fetch Track "+trackcode)
      else:
         sonofind.msg(infile+" exists",1)